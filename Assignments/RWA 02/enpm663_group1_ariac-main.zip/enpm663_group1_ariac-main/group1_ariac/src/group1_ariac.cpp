/**
 * @file group1_ariac.cpp
 * @brief
 * 
 * @copyright Copyright (c) 2025
 * 
 */

 #include <rclcpp/rclcpp.hpp>

