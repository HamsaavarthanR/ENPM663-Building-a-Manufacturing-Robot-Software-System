/**
 * @file group1_ariac.hpp
 * @brief
 * 
 * @copyright Copyright (c) 2025
 * 
 */

 #pragma once