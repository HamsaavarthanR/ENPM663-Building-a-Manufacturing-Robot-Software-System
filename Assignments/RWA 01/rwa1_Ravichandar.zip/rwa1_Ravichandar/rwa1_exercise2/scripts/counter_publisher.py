#!/usr/bin/env python3

"""
ROS 2 'counter_publisher' Publisher node.

This script initializes and runs a ROS 2 publishernode using the `CounterPublisher` class. 
It sets up the ROS 2 environment, creates the subscriber node, and manages its lifecycle.
The function of this node is to publish string to the 'counter' topic at a frequency of 2Hz.

If an exception occurs during execution, an error message is logged. The node is 
properly destroyed and ROS 2 is shut down before exiting.

"""

import rclpy
from rwa1_exercise2.counter_publisher_interface import CounterPublisher


def main(args=None):
    rclpy.init(args=args)
    node = CounterPublisher("counter_publisher")
    try:
        rclpy.spin(node)
    except Exception as e:
        rclpy.logging.get_logger("counter_publisher").error(f"Error initializing node: {e}")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()