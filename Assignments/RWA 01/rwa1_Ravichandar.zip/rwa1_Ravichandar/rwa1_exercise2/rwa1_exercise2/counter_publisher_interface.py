from rclpy.node import Node
# from std_msgs.msg import Int32
from std_msgs.msg import String


class CounterPublisher(Node):
    """
    A ROS2 publisher node that publishes an integer message to the 'counter' message topic 
    at a frequency of 2Hz.

    Attributes:
        _counter_publisher (Publisher): The ROS2 publisher object for sending string message to 'counter' topic.
        _counter_timer (Timer): A timer object that triggers the publishing event every 0.5 second.
        _counter_msg (String): A `std_msgs/msg/String` message that holds the data to be published.
        _counter (int): Variable to store counts for each publish.

    Args:
        node_name (str): The name of the node.
    """

    def __init__(self, node_name: str):
        """
        * Initializes the publisher node, creates a publisher for the 'counter' topic, and starts a timer to publish messages every half second.

        Args:
            node_name (str): The name of the node, passed to the parent Node class.
        """
        super().__init__(node_name)
        
        ## For Publisher ##
        # Create a publisher object for the 'counter' topic with a queue size of 10.
        self._counter_publisher = self.create_publisher(String, "counter", 10)
        # Create a timer that calls `counter_timer_cb` every second (2Hz).
        self._counter_timer = self.create_timer(0.5, self.counter_timer_cb)
        
        self._counter_msg = String()
        self._counter = 0
    

    ## Timer callback for publishing numbers ##
    def counter_timer_cb(self):
        """
        Callback function for the timer event. This function constructs the message to be published,
        and logs the message to the ROS2 logger.

        The message is integers each publish.
        """
        
        
        # Set the message data.
        self._counter_msg.data = str(self._counter) + ": exercise 2"
        # Publish the message.
        self._counter_publisher.publish(self._counter_msg)
        # Log the message being published.
        # self.get_logger().info(f"Publishing: {self._counter_msg.data}")
        
        # Increament _counter
        self._counter += 1
    
                
                
                
                