from rclpy.node import Node
from std_msgs.msg import String


class CounterSubscriber(Node):
    """A ROS 2 subscriber node for the 'counter' topic.

    This class creates a ROS 2 node that subscribes to the 'counter' topic and processes 
    incoming messages of type `std_msgs.msg.String. Messages received on this topic 
    are logged using the node's built-in logging mechanism.
    """

    def __init__(self, node_name: str):
        """Initialize the CounterSubscriber node.

        This constructor initializes the ROS 2 node with the given name and creates a 
        subscription to the 'counter' topic. The `counter_topic_cb` callback is registered 
        to handle incoming messages.
        
        Attributes:
            _counter_sub (Subscriber): The ROS2 subscriber object to receive messages from 'counter' topic.
            _node_name (str): Variable to store 'node_name'

        Args:
            node_name (str): The name of the ROS 2 node.
        """
        super().__init__(node_name)
        self._counter_sub = self.create_subscription(
            String, "counter", self.counter_topic_cb, 10
        )
        
        # Varible to store node_name
        self._node_name = node_name

    def counter_topic_cb(self, msg: String):
        """Handle incoming messages on the 'counter' topic.

        This function is triggered when a new message is received on the 'counter' topic.
        It logs the message content using the node's logger.

        Args:
            msg (std_msgs.msg.String): The received message object containing the String data.
        """
        self.get_logger().info(f"{self._node_name} receives: {msg.data}")
        # Logs the received message data.