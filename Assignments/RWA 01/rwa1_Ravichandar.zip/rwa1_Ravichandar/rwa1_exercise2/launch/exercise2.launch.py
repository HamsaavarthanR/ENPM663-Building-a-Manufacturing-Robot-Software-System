from launch import LaunchDescription
from launch_ros.actions import Node
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch.actions import DeclareLaunchArgument

# define a function to conditionally create executable objects using the 'Node' class,
# based on the launch arguments,
# and launch simultaneously using 'LaunchDescription' object
def generate_launch_description():
    # Initiate an instance 'ld' of the LaunchDescription' object
    ld =  LaunchDescription()
    
    # Declare Argument to accept enable 'counter_publisher' node
    declare_publisher_arg = DeclareLaunchArgument(
        'publisher_arg', default_value='false', description='Enable publisher node!'
    )

    
    # Create instances of the executables using Node class
    counter_publisher = Node(
        package="rwa1_exercise2",
        executable="counter_publisher.py",
        # Apply 'if' condition from the argument input
        condition=IfCondition(LaunchConfiguration('publisher_arg'))
    )
    
    counter_subscriber = Node(
        package="rwa1_exercise2",
        executable="counter_subscriber.py"
    )
    
    # Add executables to the 'ld' object
    ld.add_action(declare_publisher_arg)
    ld.add_action(counter_publisher)
    ld.add_action(counter_subscriber)
    
    # return object
    return ld

## ROS2 Launch system will call generate_launch_description()