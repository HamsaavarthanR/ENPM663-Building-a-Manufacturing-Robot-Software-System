#pragma once
#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/image.hpp"
#include <vector>
#include <random>
#include <chrono>
#include <cstring>


/**
 * @class CameraPublisher
 * @brief A ROS2 subscriber node class.
 *
 * CameraPublisher is a class derived from rclcpp::Node designed to publish to
 * 'Image' messages on a topic named "camera". This class is created to 
 * demonstrate launching multiple nodes as groups with enabled topic remapping
 * in the launch arguments
 */
class CameraPublisher : public rclcpp::Node
{
public:
    /**
     * @brief Constructs a CameraPublisher with a specified name.
     *
     * Initializes the publisher to plush on the "camera" topic for messages
     * of type sensor_msgs::msg::Image. It binds the publish_camera_data function to
     * be called at a frequency of 2Hz.
     *
     * @param node_name The name of the node.
     */
    CameraPublisher()
        : Node("camera_publisher")
    {
        publisher_ = this->create_publisher<sensor_msgs::msg::Image>("camera", 10);
        timer_ = this->create_wall_timer(
            std::chrono::milliseconds(500), // 2 Hz
            std::bind(&CameraPublisher::publish_camera_data, this));
        // RCLCPP_INFO(this->get_logger(), "camera_demo node started");
    }

private:
    /**
     * @brief callback function to publish message to 'camera' topic.
     *
     * This function creates a random image of type sensor_msgs.msg.Image,
     * and publish to the topic 'camera' for every half a second.
     *
     * @param 
     */
    void publish_camera_data();

    rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr publisher_;
    rclcpp::TimerBase::SharedPtr timer_;
};
