#include <rwa1_exercise3/camera_publisher_interface.hpp>


void CameraPublisher::publish_camera_data()
{
    auto camera_message = sensor_msgs::msg::Image();
    
    // Set header information
    camera_message.header.stamp = this->get_clock()->now();
    camera_message.header.frame_id = "camera_frame";

    // Set image parameters
    const uint32_t width = 640;  // Image width
    const uint32_t height = 480; // Image height
    const uint32_t channels = 3; // RGB
    const uint32_t step = width * channels;

    camera_message.height = height;
    camera_message.width = width;
    camera_message.encoding = "rgb8";
    camera_message.is_bigendian = false;
    camera_message.step = step;

    // Generate random pixel data
    std::vector<uint8_t> data(height * step);
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> pixel_dist(0, 255);

    for (auto &pixel : data)
    {
        pixel = static_cast<uint8_t>(pixel_dist(gen));
    }

    camera_message.data = data;

    // Publish the message
    publisher_->publish(camera_message);
    // RCLCPP_INFO(this->get_logger(), "Published random camera image");
}

int main(int argc, char *argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<CameraPublisher>());
    rclcpp::shutdown();
}