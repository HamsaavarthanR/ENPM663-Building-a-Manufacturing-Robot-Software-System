from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import GroupAction
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration


def generate_launch_description():
    
    ld = LaunchDescription()
    
    # Declare the argument for the camera1 topic name
    camera1_arg = DeclareLaunchArgument(
        "camera1_topic",
        default_value="camera1",
        description="The topic name to remap camera1 scan topic",
    )

    # Declare the argument for the camera2 topic name
    camera2_arg = DeclareLaunchArgument(
        "camera2_topic",
        default_value="camera2",
        description="The topic name to remap camera2 scan topic",
    )
    # Use the LaunchConfiguration to get the argument value
    camera1_topic = LaunchConfiguration("camera1_topic")
    camera2_topic = LaunchConfiguration("camera2_topic")
    
    
    # Add Argument declaration
    ld.add_action(camera1_arg)
    ld.add_action(camera2_arg)

    
    # Define and group 'camera_publisher' and 'camera_subscriber' nodes together for remapping topic 'camera' case
    camera_group = GroupAction([
        Node(package='rwa1_exercise3', executable='camera_publisher', name='camera1_publisher', remappings=[("camera", camera1_topic),],),
        Node(package='rwa1_exercise3', executable='camera_publisher', name='camera2_publisher', remappings=[("camera", camera2_topic),],),
        Node(package='rwa1_exercise3', executable='camera_subscriber.py', name='camera1_subscriber', remappings=[("camera", camera1_topic)],),
        Node(package='rwa1_exercise3', executable='camera_subscriber.py', name='camera2_subscriber', remappings=[("camera", camera2_topic)],),])
    

    # Add executables
    ld.add_action(camera_group)
    return ld