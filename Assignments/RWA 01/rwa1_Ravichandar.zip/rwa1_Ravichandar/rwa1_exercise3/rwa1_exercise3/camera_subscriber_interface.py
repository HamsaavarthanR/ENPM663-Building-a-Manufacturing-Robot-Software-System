from rclpy.node import Node
from sensor_msgs.msg import Image


class CameraSubscriber(Node):
    """A ROS 2 subscriber node for the 'camera' topic.

    This class creates a ROS 2 node that subscribes to the 'camera'
    and processes incoming messages of type 'sensor_msgs.msg.Image'. Messages received on this topic 
    are logged using the node's built-in logging mechanism.
    """

    def __init__(self, node_name: str):
        """Initialize the CameraSubscriber node.

        This constructor initializes the ROS 2 node with the given name and creates a 
        subscription to the 'camera' topic. The `camera_topic_cb` callback is registered 
        to handle incoming messages.
        
        Attributes:
            _camera_sub (Subscriber): The ROS2 subscriber object to receive messages from 'camera' topic.
            _node_name (str): Variable to store 'node_name'

        Args:
            node_name (str): The name of the ROS 2 node.
        """
        super().__init__(node_name)
        self._camera_sub = self.create_subscription(
            Image, "camera", self.camera_topic_cb, 10
        )
        
        # Varible to store node_name
        self._node_name = node_name

    def camera_topic_cb(self, img: Image):
        """Handle incoming messages on the 'camera' topic.

        This function is triggered when a new message is received on the 'camera' topic.
        It logs the message content using the node's logger.
        """
        self.get_logger().info(f"{self._node_name} receives camera data")
        # Logs the received message data.