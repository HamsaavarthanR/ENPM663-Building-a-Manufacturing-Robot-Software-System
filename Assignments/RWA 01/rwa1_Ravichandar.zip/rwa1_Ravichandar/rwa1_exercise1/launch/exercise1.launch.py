from launch import LaunchDescription
from launch_ros.actions import Node

# define a function to create executable objects using the 'Node' class and 
# launch simultaneously using 'LaunchDescription' object
def generate_launch_description():
    # Initiate an instance 'ld' of the LaunchDescription' object
    ld =  LaunchDescription()
    
    # Create instances of the executables using Node class
    number_publisher = Node(
        package="rwa1_exercise1",
        executable="number_publisher.py"
    )
    
    alphabet_publisher = Node(
        package="rwa1_exercise1",
        executable="alphabet_publisher.py"
    )
    
    # Add executables to the 'ld' object
    ld.add_action(number_publisher)
    ld.add_action(alphabet_publisher)
    
    # return object
    return ld

## ROS2 Launch system will call generate_launch_description()