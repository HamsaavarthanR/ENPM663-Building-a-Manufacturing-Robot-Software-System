#!/usr/bin/env python3

"""
ROS 2 'number_publisher' bi-directionally communicable node.

This script initializes and runs a ROS 2 publisher/subscrider node using the `NumberPublisher` class. 
It sets up the ROS 2 environment, creates the subscriber node, and manages its lifecycle.
The function of this node is to publish integers 1 to 20 to the 'numbers' topic,
at the same time subscribe and print the messages received from 'letters' topic.

If an exception occurs during execution, an error message is logged. The node is 
properly destroyed and ROS 2 is shut down before exiting.

"""

import rclpy
from rwa1_exercise1.number_publisher_interface import NumberPublisher


def main(args=None):
    rclpy.init(args=args)
    node = NumberPublisher("number_publisher")
    try:
        rclpy.spin(node)
    except Exception as e:
        rclpy.logging.get_logger("number_publisher").error(f"Error initializing node: {e}")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()