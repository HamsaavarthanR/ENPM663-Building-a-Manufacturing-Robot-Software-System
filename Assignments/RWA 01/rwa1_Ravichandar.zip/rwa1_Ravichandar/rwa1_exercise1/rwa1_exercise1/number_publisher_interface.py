from rclpy.node import Node
from std_msgs.msg import String
from std_msgs.msg import Int32


class NumberPublisher(Node):
    """
    A ROS2 publisher node that publishes an integer message from 1 to 20, restarting from 1, to the 'numbers' topic 
    at a frequency of 1Hz. Then, subcribes to the topic 'letters' and prints the received message to the terminal.

    Attributes:
        _number_publisher (Publisher): The ROS2 publisher object for sending integers 1 to 20 to 'numbers' topic.
        _number_timer (Timer): A timer object that triggers the publishing event every 1 second.
        _number_msg (Int32): A `std_msgs/msg/Int32` message that holds the data to be published.
        _number_counter : Variable to increament integer from 1 to 20 for each second.
        _letters_sub (Subscriber): The ROS2 subscriber object to receive messages from 'letters' topic.

    Args:
        node_name (str): The name of the node.
    """

    def __init__(self, node_name):
        """
        * Initializes the publisher node, creates a publisher for the 'numbers' topic, and starts a timer to publish messages every second.
        * Initializes the subscriber node, creates a subcriber to the 'letters' topic.

        Args:
            node_name (str): The name of the node, passed to the parent Node class.
        """
        super().__init__(node_name)
        
        ## For Publisher ##
        # Create a publisher object for the 'numbers' topic with a queue size of 10.
        self._number_publisher = self.create_publisher(Int32, "numbers", 10)
        # Create a timer that calls `number_timer_cb` every second (1Hz).
        self._number_timer = self.create_timer(1.0, self.number_timer_cb)
        
        self._number_msg = Int32()
        self._number_counter = 0
        
        ## For Subscriber ##
        self._letters_sub = self.create_subscription(
            String, "letters", self.letters_topic_cb, 10
        )

    ## Timer callback for publishing numbers ##
    def number_timer_cb(self):
        """
        Callback function for the timer event. This function constructs the message to be published,
        and logs the message to the ROS2 logger.

        The message is integers 1 to 20 for each publish and then starting over again.
        """
        
        self._number_counter += 1
        if self._number_counter < 20:
            # Set the message data.
            self._number_msg.data = self._number_counter
            # Publish the message.
            self._number_publisher.publish(self._number_msg)
            # Log the message being published.
            # self.get_logger().info(f"Publishing: {self._number_msg.data}")
        else:
            self._number_counter = 0
    
    ## Subscription callback for printing message ##            
    def letters_topic_cb(self, msg: String):
        """Handle incoming messages on the 'letters' topic.

        This function is triggered when a new message is received on the 'letters' topic.
        It logs the message content using the node's logger.

        Args:
            msg (std_msgs.msg.String): The received message object containing the string data.
        """
        self.get_logger().info(f"number_publisher receives: {msg.data}")
        # Logs the received message data.
                
                
                

