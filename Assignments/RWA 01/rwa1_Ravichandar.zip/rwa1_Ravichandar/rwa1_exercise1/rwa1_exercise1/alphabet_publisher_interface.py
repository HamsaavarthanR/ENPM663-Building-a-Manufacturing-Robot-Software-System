from rclpy.node import Node
from std_msgs.msg import String
from std_msgs.msg import Int32


class AlphabetPublisher(Node):
    """
    A ROS2 publisher node that publishes a message from a to z, restarting from a, to the 'letters' topic 
    at a frequency of 1Hz. Then, subcribes to the topic 'numbers' and prints the received message to the terminal.

    Attributes:
        _letter_publisher (Publisher): The ROS2 publisher object for sending string a to z to 'letters' topic.
        _letter_timer (Timer): A timer object that triggers the publishing event every 1 second.
        _letter_msg (String): A `std_msgs/msg/Int32` message that holds the data to be published.
        _letter_counter : Variable to increament string from a to z for each second.
        _alphabets : variable to store a string of alphabets from a to z.
        _numbers_sub (Subscriber): The ROS2 subscriber object to receive messages from 'numbers' topic.

    Args:
        node_name (str): The name of the node.
    """

    def __init__(self, node_name):
        """
        * Initializes the publisher node, creates a publisher for the 'letters' topic, and starts a timer to publish messages every second.
        * Initializes the subscriber node, creates a subcriber to the 'numbers' topic.

        Args:
            node_name (str): The name of the node, passed to the parent Node class.
        """
        super().__init__(node_name)
        
        ## For Publisher ##
        # Create a publisher object for the 'letters' topic with a queue size of 10.
        self._letter_publisher = self.create_publisher(String, "letters", 10)
        # Create a timer that calls `letter_timer_cb` every second (1Hz).
        self._letter_timer = self.create_timer(1.0, self.letter_timer_cb)
        
        self._letter_msg = String()
        self._letter_counter = 0
        self._alphabets = "abcdefghijklmnopqrstuvwxyz"
        
        ## For Subscriber ##
        self._numbers_sub = self.create_subscription(
            Int32, "numbers", self.numbers_topic_cb, 10
        )
        

    def letter_timer_cb(self):
        """
        Callback function for the timer event. This function constructs the message to be published,
        and logs the message to the ROS2 logger.

        The message is letters a to z for each publish and then starting over again.
        """
        
        
        if self._letter_counter < 26:
            # Set the message data.
            self._letter_msg.data = self._alphabets[self._letter_counter]
            # Publish the message.
            self._letter_publisher.publish(self._letter_msg)
            # Log the message being published.
            # self.get_logger().info(f"Publishing: {self._letter_msg.data}")
            
            # Increament the counter
            self._letter_counter += 1
            
        else:
            self._letter_counter = 0
                
    
    ## Subscription callback for printing message ##            
    def numbers_topic_cb(self, msg: Int32):
        """Handle incoming messages on the 'numbers' topic.

        This function is triggered when a new message is received on the 'numbers' topic.
        It logs the message content using the node's logger.

        Args:
            msg (std_msgs.msg.Int32): The received message object containing the string data.
        """
        self.get_logger().info(f"alphabet_publisher receives: {msg.data}")
        # Logs the received message data.

